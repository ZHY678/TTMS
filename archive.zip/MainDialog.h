#pragma once
#include "StereoCameraDlg.h"
#include "MeasureDistance.h"
#include "CameraCalib.h"
#include "Camera.h"
#include "tchart1.h"

// CMainDialog dialog

class CMainDialog : public CDialogEx
{
	DECLARE_DYNAMIC(CMainDialog)

public:
	CMainDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMainDialog();

// Dialog Data
	enum { IDD = IDD_MAIN_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	
	CString m_workDir;
	MeasureDistance m_measureDist;
	CameraCalib::CalibrationParames m_CalibrationResult;
	double m_CameraHeigh;        //������߶�
	Mat m_rotateMat;    //�������������
	CStereoCameraDlg m_stereDlg;
	Camera m_camera;

	CString GetAppExecPath();


	virtual BOOL OnInitDialog();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnBnClickedButton2();
	CTChart m_chart3;
	afx_msg void OnBnClickedBncaculatemain();
};
