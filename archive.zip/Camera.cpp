#include "stdafx.h"
#include "Camera.h"


Camera::Camera()
{
}


Camera::~Camera()
{
}

bool Camera::CameraInit(int type, int deviceid)
{
	//mindvision
	if (type == MIND)
	{
		//CameraSdkInit(1);//"��ʼ��
		return true;
	}
	//UVC
	else if (type == UVC)
	{
		bool iosopen = camDs.OpenCamera(deviceid, true);
		if (!iosopen) {
			return false;
		}
		return true;
	}
	else
	{

	}


	return false;
}

Mat Camera::getPicture()
{
	frame = camDs.QueryFrame();
	return frame;
}