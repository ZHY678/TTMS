﻿
// StereoCameraDlg.cpp : 实现文件
//

#include "stdafx.h"
#include "StereoCamera.h"
#include "StereoCameraDlg.h"
#include "afxdialogex.h"

#include "CameraCalib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


/*             MINDVISION SDK
//相机1图像抓取线程，主动调用SDK接口函数获取图像
UINT WINAPI LfCamDisplayThread(LPVOID lpParam)
{
	tSdkFrameHead sFrameInfo;
	CStereoCameraDlg* pThis = (CStereoCameraDlg*)lpParam;
	BYTE* pbyBuffer;
	CameraSdkStatus status;

	while (!pThis->m_bExit[0])
	{
		if (CameraGetImageBuffer(pThis->m_hCamera[0], &sFrameInfo, &pbyBuffer, 500) == CAMERA_STATUS_SUCCESS)
		{
			status = CameraImageProcess(pThis->m_hCamera[0], pbyBuffer, pThis->m_pFrameBuffer[0], &sFrameInfo);

			//分辨率改变了，则刷新背景
			if (pThis->m_sFrInfo[0].iWidth != sFrameInfo.iWidth || pThis->m_sFrInfo[0].iHeight != sFrameInfo.iHeight)
			{
				pThis->m_sFrInfo[0].iWidth = sFrameInfo.iWidth;
				pThis->m_sFrInfo[0].iHeight = sFrameInfo.iHeight;
				pThis->InvalidateRect(NULL);
			}

			if (status == CAMERA_STATUS_SUCCESS)
			{
				//调用SDK封装好的显示接口来显示图像
				CameraImageOverlay(pThis->m_hCamera[0], pThis->m_pFrameBuffer[0], &sFrameInfo);
				CameraDisplayRGB24(pThis->m_hCamera[0], pThis->m_pFrameBuffer[0], &sFrameInfo);
			}

			CameraReleaseImageBuffer(pThis->m_hCamera[0], pbyBuffer);

			memcpy(&pThis->m_sFrInfo[0], &sFrameInfo, sizeof(tSdkFrameHead));

		}
	}

	_endthreadex(0);
	return 0;
}

//相机1图像抓取线程，主动调用SDK接口函数获取图像
UINT WINAPI RtCamDisplayThread(LPVOID lpParam)
{
	tSdkFrameHead sFrameInfo;
	CStereoCameraDlg* pThis = (CStereoCameraDlg*)lpParam;
	BYTE* pbyBuffer;
	CameraSdkStatus status;

	while (!pThis->m_bExit[1])
	{
		if (CameraGetImageBuffer(pThis->m_hCamera[1], &sFrameInfo, &pbyBuffer, 500) == CAMERA_STATUS_SUCCESS)
		{
			status = CameraImageProcess(pThis->m_hCamera[1], pbyBuffer, pThis->m_pFrameBuffer[1], &sFrameInfo);

			//分辨率改变了，则刷新背景
			if (pThis->m_sFrInfo[1].iWidth != sFrameInfo.iWidth || pThis->m_sFrInfo[1].iHeight != sFrameInfo.iHeight)
			{
				pThis->m_sFrInfo[1].iWidth = sFrameInfo.iWidth;
				pThis->m_sFrInfo[1].iHeight = sFrameInfo.iHeight;
				pThis->InvalidateRect(NULL);
			}

			if (status == CAMERA_STATUS_SUCCESS)
			{
				//调用SDK封装好的显示接口来显示图像
				CameraImageOverlay(pThis->m_hCamera[1], pThis->m_pFrameBuffer[1], &sFrameInfo);
				CameraDisplayRGB24(pThis->m_hCamera[1], pThis->m_pFrameBuffer[1], &sFrameInfo);
			}

			CameraReleaseImageBuffer(pThis->m_hCamera[1], pbyBuffer);

			memcpy(&pThis->m_sFrInfo[1], &sFrameInfo, sizeof(tSdkFrameHead));

		}
	}

	_endthreadex(0);
	return 0;
}
*/

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// CStereoCameraDlg 对话框

CStereoCameraDlg::CStereoCameraDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CStereoCameraDlg::IDD, pParent)
	, m_nBoardWidth(0)
	, m_nBoardHeight(0)
	, m_nPixelSize(0)
	, m_CameraSelect(_T(""))
{
	//OpenGL
	//m_hDC = NULL;
	//m_hRC = NULL;

	//MINDVISION 
	//for (int i = 0; i < 2; i++)
	//{
	//	m_pFrameBuffer[i] = NULL;
	//	m_bExit[i] = FALSE;
	//	m_hDispThread[i] = NULL;
	//}


	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStereoCameraDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_BoardWidth, m_nBoardWidth);
	DDX_Text(pDX, IDC_BoardHeight, m_nBoardHeight);
	DDX_Text(pDX, IDC_PixelSize, m_nPixelSize);
	DDX_Text(pDX, IDC_SquareSize, m_nSquareSize);
	DDX_Control(pDX, IDC_PicLfCam, m_PicLfArea);
	DDX_Control(pDX, IDC_PicRtCam, m_PicRtArea);
	//DDX_Check(pDX, IDC_RAD_CalibFromCam, m_calibFromCam);
	DDX_Control(pDX, IDC_LIST_STATUS, m_RunStaInfo);
	DDX_Text(pDX, IDC_CameraHeigh, m_CameraHeigh);


	DDX_Control(pDX, IDC_TCHART2, m_chart2);
	DDX_CBString(pDX, IDC_CameraSelect, m_CameraSelect);
	DDX_Control(pDX, IDC_CameraSelect, m_CameraSelectCombox);
	DDX_Control(pDX, IDC_PicDraw, m_picDraw);
}

BEGIN_MESSAGE_MAP(CStereoCameraDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BN2StereoCalib, &CStereoCameraDlg::OnBnClickedBn2stereocalib)
	ON_BN_CLICKED(IDC_BNSetLfCam, &CStereoCameraDlg::OnBnClickedBnsetlfcam)
	ON_BN_CLICKED(IDC_BNSetRtCam, &CStereoCameraDlg::OnBnClickedBnsetrtcam)	
	ON_BN_CLICKED(IDC_BNRunCam, &CStereoCameraDlg::OnBnClickedBnruncam)
	ON_BN_CLICKED(IDC_BN_DefaultCamCalibParam, &CStereoCameraDlg::OnBnClickedBnDefaultcamcalibparam)	
	ON_BN_CLICKED(IDC_BNGrabBothCam, &CStereoCameraDlg::OnBnClickedBngrabbothcam)
	ON_BN_CLICKED(IDC_BNSaveCalibParams, &CStereoCameraDlg::OnBnClickedBnsavecalibparams)
	ON_BN_CLICKED(IDC_BNBw, &CStereoCameraDlg::OnBnClickedBnbw)
	ON_BN_CLICKED(IDC_BNXiuZheng, &CStereoCameraDlg::OnBnClickedBnxiuzheng)
	ON_BN_CLICKED(IDC_BNReadFromMatlab, &CStereoCameraDlg::OnBnClickedBnreadfrommatlab)
	ON_CBN_SELCHANGE(IDC_CameraSelect, &CStereoCameraDlg::OnCbnSelchangeCameraselect)
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_BNCalculate, &CStereoCameraDlg::OnBnClickedBncalculate)
END_MESSAGE_MAP()

// CStereoCameraDlg 消息处理程序

BOOL CStereoCameraDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	//获取摄像头数目
	int cam_count = CCameraDS::CameraCount();
	//获取所有摄像头的名称
	map<int, string> cam_map;
	if (cam_count >0)
	{
		for (int i = 0; i < cam_count; i++)
		{
			char camera_name[1024];
			int retval = CCameraDS::CameraName(i, camera_name, sizeof(camera_name));

			if (retval > 0){
				cam_map.insert(make_pair(i, string(camera_name)));
				m_CameraSelectCombox.InsertString(i, _T(camera_name));
			}
		}
		m_CameraSelectCombox.SetCurSel(0);
	}
	
	//-------------------     SDK             -------------------//
	// 根据当前已经连到电脑上的相机个数来初始化。支持4个相机同时显示。
	//m_camType = Camera::CAM_TYPE::MIND;
	//CheckRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg, IDC_RAD_CalcFromCam);
	//GetDlgItem(IDC_BNRunCam)->EnableWindow(TRUE);
	//CameraSdkInit(1);//"初始化
	//bool cam_bool = InitCamera();
	//if (!cam_bool)
	//{
	//	CheckRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg, IDC_RAD_CalcFromImg);
	//	GetDlgItem(IDC_BNRunCam)->EnableWindow(FALSE);
	//	//return FALSE;
	//}
	//
	//if (!cam_bool)
	//{
		m_camType = Camera::CAM_TYPE::UVC;
		CheckRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg, IDC_RAD_CalcFromCam);
		GetDlgItem(IDC_BNRunCam)->EnableWindow(TRUE);
		if (!(cam_count>0))
		{
			CheckRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg, IDC_RAD_CalcFromImg);
			GetDlgItem(IDC_BNRunCam)->EnableWindow(FALSE);
			AfxMessageBox(_T("No UVC Camera was found!"));
		}
	//}
	
	////init OpenGL
	////CWnd* wnd = GetDlgItem(IDC_ResRenderPic);
	////m_hDC = ::GetDC(wnd->m_hWnd); 
	////if (!InitOpenGL(m_hDC))
	////{
	////	return FALSE;
	////}

	//获取工作路径
	m_workDir = GetAppExecPath();

	//读取标定数据;
	m_CalibrationResult.sCaliResultFilePath.Format(_T("%s\\CalibrationResult"), m_workDir);
	m_CalibrationResult.bIsBinocularCameraCalibration = 1;
	bool bCaliSucflag = m_CalibrationResult.ReadYMLFile();
	
	//默认标定参数，从文件中读取
	m_nBoardHeight = m_CalibrationResult.dBoardHeight;
	m_nBoardWidth = m_CalibrationResult.dBoardWidth;
	m_nSquareSize = m_CalibrationResult.dSquareSize;
	m_nPixelSize = m_CalibrationResult.dPixelSize;

	m_CameraHeigh = m_CalibrationResult.dCameraHeigh;
	m_rotateMat = m_CalibrationResult.amendRotMat;

	if (bCaliSucflag)
	{
		CString str;
		str.Empty();
		str.Format(_T("左相机焦距：%fmm"), m_CalibrationResult.dLeftCameraFocalLen);
		RunStateInfoShow(str);

		str.Empty();
		str.Format(_T("右相机焦距：%fmm"), m_CalibrationResult.dRightCameraFocalLen);
		RunStateInfoShow(str);

		str.Empty();
		str.Format(_T("标定误差：%fmm"), m_CalibrationResult.dCaliratebError);
		RunStateInfoShow(str);

		str.Empty();
		str.Format(_T("标定时间：%s"), m_CalibrationResult.strCalibrateTime);
		RunStateInfoShow(str);

	}
	else
	{
		RunStateInfoShow(_T("标定文件不存在。"));
	}

	m_chart2.GetHeader().GetText().SetItem(0, COleVariant("示图"));
	m_chart2.GetAxis().GetBottom().GetTitle().SetCaption("Z轴");
	m_chart2.GetAxis().GetLeft().GetTitle().SetCaption("Y轴");


	UpdateData(FALSE);
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CStereoCameraDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CStereoCameraDlg::OnPaint()
{
	//ClientToScreen(&m_mousePoint);
	CRect rect;
	GetDlgItem(IDC_PicDraw)->GetClientRect(rect);
	GetDlgItem(IDC_PicDraw)->ClientToScreen(rect);
	CDC *pDC = GetDlgItem(IDC_PicDraw)->GetDC();
	DrawPic(pDC, rect);

	/*if (rect.PtInRect(m_mousePoint))
	{
		CPen newPen;
		CPen* oldPen;
		CBrush newBrush;
		CBrush* pOldBrush;

		newBrush.CreateSolidBrush(RGB(255, 255, 255));
		pOldBrush = pDC->SelectObject(&newBrush);
		pDC->Rectangle(rect);
		pDC->SelectObject(pOldBrush);
		newBrush.DeleteObject();

		newPen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
		oldPen = pDC->SelectObject(&newPen);

		int x = m_mousePoint.x - rect.left;
		int y = m_mousePoint.y - rect.top;

		pDC->MoveTo(0, y);
		pDC->LineTo(rect.Width(), y);
		pDC->MoveTo(x, 0);
		pDC->LineTo(x, rect.Height());

		pDC->SelectObject(oldPen);
		newPen.DeleteObject();
	}
	*/
	
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CStereoCameraDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


//////////////////////////////////////////////////////////////////////////
/*----------------------------------
* 功能 :	获取程序运行时所在的文件夹路径
*----------------------------------
* 函数 :	CStereoVisionDlg::F_GetAppExecPath
* 访问 :	private
* 返回 :	程序运行时所在的文件夹路径
*/
CString CStereoCameraDlg::GetAppExecPath()
{
	CString strPath;
	TCHAR path[_MAX_PATH];
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	::GetModuleFileName(AfxGetApp()->m_hInstance, path, _MAX_PATH);
	_tsplitpath(path, drive, dir, fname, ext);

	strPath.Empty();
	strPath += CString(drive);
	strPath += CString(dir);

	return strPath;
}


/*----------------------------
*功能 :初始化摄像头
*----------------------------
*返回 : bool   true正常初始化，false初始化异常
*
*
bool CStereoCameraDlg::InitCamera()
{
	tSdkCameraDevInfo sCameraList[2];
	int iCameraNums;
	CameraSdkStatus status;
	CRect rect;
	tSdkCameraCapbility sCameraInfo;
	int i;
	//枚举设备，获得设备列表
	iCameraNums = 2;//调用CameraEnumerateDevice前，先设置iCameraNums = 4，表示最多只读取4个设备，
					//如果需要枚举更多的设备，请更改sCameraList数组的大小和iCameraNums的值,
					//最多支持16个相机
	
	if (CameraEnumerateDevice(sCameraList, &iCameraNums) != CAMERA_STATUS_SUCCESS || iCameraNums == 0)
	{
		AfxMessageBox(_T("No MINDVISION camera was found!"));
		return FALSE;
	}

	for (i = 0; i < iCameraNums; i++)
	{
		if ((status = CameraInit(&sCameraList[i], -1, -1, &m_hCamera[i])) != CAMERA_STATUS_SUCCESS)
		{
			CString msg;
			msg.Format(_T("Failed to init the camera %s! Error code is %d"), status, sCameraList[i].acFriendlyName);
			AfxMessageBox(msg);
		}
		else{
			//初始化成功，进行进一步操作
			//Get properties description for this camera.
			CameraGetCapability(m_hCamera[i], &sCameraInfo);//"获得该相机的特性描述"
			m_pFrameBuffer[i] = (BYTE *)CameraAlignMalloc(sCameraInfo.sResolutionRange.iWidthMax*sCameraInfo.sResolutionRange.iHeightMax * 3, 16);

			ASSERT(m_pFrameBuffer[i]);

			//使用SDK封装好的显示接口
			switch (i)
			{
			case 0:
				CameraDisplayInit(m_hCamera[i], m_PicLfArea.GetSafeHwnd());
				m_PicLfArea.GetClientRect(&rect);
				//Set display window size
				CameraSetDisplaySize(m_hCamera[i], rect.right - rect.left, rect.bottom - rect.top);//"设置显示窗口大小";
#ifdef USE_CALLBACK_GRAB_IMAGE //如果要使用回调函数方式，定义USE_CALLBACK_GRAB_IMAGE这个宏
				//Set the callback for image capture
				CameraSetCallbackFunction(m_hCamera[i], GrabImageCallback1, (PVOID)this, NULL);//"设置图像抓取的回调函数";
#else
				m_hDispThread[i] = (HANDLE)_beginthreadex(NULL, 0, &LfCamDisplayThread, this, 0, &m_threadID[i]);
				ASSERT(m_hDispThread[i]);
				SetThreadPriority(m_hDispThread, THREAD_PRIORITY_HIGHEST);
#endif
				break;
			
			case 1:
				CameraDisplayInit(m_hCamera[i], m_PicRtArea.GetSafeHwnd());
				m_PicRtArea.GetClientRect(&rect);

				CameraSetDisplaySize(m_hCamera[i], rect.right - rect.left, rect.bottom - rect.top);//"设置显示窗口大小";
#ifdef USE_CALLBACK_GRAB_IMAGE //如果要使用回调函数方式，定义USE_CALLBACK_GRAB_IMAGE这个宏
				//Set the callback for image capture
				CameraSetCallbackFunction(m_hCamera[i], GrabImageCallback1, (PVOID)this, NULL);//"设置图像抓取的回调函数";
#else
				m_hDispThread[i] = (HANDLE)_beginthreadex(NULL, 0, &RtCamDisplayThread, this, 0, &m_threadID[i]);
				ASSERT(m_hDispThread[i]);
				SetThreadPriority(m_hDispThread, THREAD_PRIORITY_HIGHEST);
#endif
				break;
			}

			//Create the settings window for the camera
			CameraCreateSettingPage(m_hCamera[i], GetSafeHwnd(),
				sCameraList[i].acFriendlyName, NULL, NULL, 0);


			//Tell the camera begin to sendding image
			//CameraPlay(m_hCamera[i]);//"开始预览";
		}
	}

	return true;	
}
*/


void CStereoCameraDlg::OnClose()
{
	//MINDVISION camera 释放
	/*
	int i;
	for (i = 0; i < 2; i++)
	{
		//反初始化相机
		if (m_hCamera[i] > 0)
		{
			if (NULL != m_hDispThread[i])
			{
				//等待采集线程结束
				m_bExit[i] = TRUE;
				::WaitForSingleObject(m_hDispThread[i], 2000);
				CloseHandle(m_hDispThread[i]);
				m_hDispThread[i] = NULL;
			}

			//反初始化相机。
			CameraUnInit(m_hCamera[i]);
			m_hCamera[i] = 0;
		}

		if (m_pFrameBuffer[i])
		{
			CameraAlignFree(m_pFrameBuffer[i]);
			m_pFrameBuffer[i] = NULL;
		}
	}
	*/

	//释放OpenGL
	//m_hRC = ::wglGetCurrentContext();
	//if (::wglDeleteContext(m_hRC)==FALSE)
	//{
	//	AfxMessageBox(_T("Could not delete RC."));
	//}

	//if (m_hDC)
	//{
	//	delete m_hDC;
	//}
	//m_hDC = NULL;

	CDialog::OnClose();
}



/*----------------------------
* 功能 : 显示图像
*		 将要绘制的图像 src 显示到控件号为 ID 的 Picture 控件
*----------------------------
* 参数 : src	[in]	待显示图像
* 参数 : ID		[in]	图像窗口控件ID
*/
void CStereoCameraDlg::ShowImage(Mat& src, UINT ID)
{
	if (src.empty())
	{
		return;
	}

	CDC* pDC = GetDlgItem(ID)->GetDC();		// 获得显示控件的 DC
	HDC hDC = pDC->GetSafeHdc();				// 获取 HDC(设备句柄) 来进行绘图操作
	CRect rect;
	GetDlgItem(ID)->GetClientRect(&rect);	// 获取控件尺寸位置
	CvvImage cimg;
	IplImage src_img = src;
	cimg.CopyOf(&src_img);						// 复制图片
	cimg.DrawToHDC(hDC, &rect);				// 将图片绘制到显示控件的指定区域内
	ReleaseDC(pDC);
}

/*----------------------------
* 功能 : 弹出打开文件对话框，选择单个或多个文件
*----------------------------
* 函数 : CStereoVisionDlg::DoSelectFiles
* 访问 : private
* 返回 : selectedFiles	选择的文件的路径序列
*
* 参数 : lpszDefExt			[in]	文件默认格式
* 参数 : dwFlags			[in]	对话框选项
* 参数 : lpszFilter			[in]	文件格式过滤条件
* 参数 : lpstrTitle			[in]	对话框标题
* 参数 : lpstrInitialDir	[in]	对话框的初始路径
*/
vector<CStringA> CStereoCameraDlg::DoSelectFiles(
	LPCTSTR	lpszDefExt,
	DWORD	dwFlags,
	LPCTSTR	lpszFilter,
	LPCTSTR	lpstrTitle,
	LPCTSTR	lpstrInitialDir)
{
	vector<CStringA> selectedFiles;
	POSITION filePosition;
	DWORD MAXFILE = 4000;
	TCHAR* pc = new TCHAR[MAXFILE];

	CFileDialog dlg(TRUE, lpszDefExt, NULL, dwFlags, lpszFilter, NULL);

	dlg.m_ofn.nMaxFile = MAXFILE;
	dlg.m_ofn.lpstrFile = pc;
	dlg.m_ofn.lpstrFile[0] = NULL;
	dlg.m_ofn.lpstrTitle = lpstrTitle;
	dlg.m_ofn.lpstrInitialDir = lpstrInitialDir;

	if (dlg.DoModal() == IDOK)
	{
		filePosition = dlg.GetStartPosition();
		while (filePosition != NULL)
		{
			CStringA path;
			path = dlg.GetNextPathName(filePosition);
			selectedFiles.push_back(path);
		}
	}

	delete[]pc;
	return selectedFiles;
}


void CStereoCameraDlg::OnBnClickedBn2stereocalib()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_cameraInitFlag)
	{
		//暂停摄像机
		if (m_camType == Camera::CAM_TYPE::MIND)
		{
			//CameraPause(m_hCamera[0]);
			//CameraPause(m_hCamera[1]);
		}
		else
		{
			KillTimer(1);
		}
	}
	
	int nImages; //总共的图像张数
	int nImgCount = 0;   //图像计数
	vector<CStringA> img0Files, img1Files;
	const char* img0_file = NULL, *img1_file = NULL;
	cv::Mat frame0, frame1, img0, img1;
	cv::Size imageSize;

	CameraCalib::CornerDatas cornerDatas;
	
	try{
		// 选择从本地图片读入定标图像，首先弹出对话框选择图片文件
		img0Files = DoSelectFiles(
			_T("*.bmp"),
			OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
			_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
			_T("选择左视图文件"),
			_T("Imgs\\Left"));
		img1Files = DoSelectFiles(
			_T("*.bmp"),
			OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
			_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
			_T("选择右视图文件"),
			_T("Imgs\\Right"));

		if (img0Files.empty() || img1Files.empty())	// 判断是否获得图片
		{
			LPCTSTR errMsg = _T("没有选择到有效的图像文件，请重新选择!");
			throw errMsg;
		}


		img0_file = img0Files[0];
		img0 = cvLoadImage(img0_file);
		imageSize = img0.size();
		nImages = MIN(img0Files.size(), img1Files.size());
		Size imgSize = img0.size();
		Size boardSize(m_nBoardWidth, m_nBoardHeight);
				
		//图像小于5张 不能标定
		if (nImages < 3)
		{
			LPCTSTR errMsg = _T("图像少于3张，不能标定！");
			throw errMsg;
		}

		RunStateInfoShow(_T("开始进行标定..."));

		//初始化角点数据集
		m_cameraCalibrator.initCornerData(nImages, imgSize, boardSize, m_nSquareSize, cornerDatas);
			
		// 开始检测角点
		MSG msg;
		while (nImgCount < nImages)
		{
			// MFC 窗口消息处理
			if (::PeekMessage(&msg, this->m_hWnd, 0, 0, PM_REMOVE))
			{
				if (msg.message == WM_QUIT)
				{
					LPCTSTR errMsg = _T("手动退出双目标定!");
					throw errMsg;
				}

				::TranslateMessage(&msg);
				::DispatchMessage(&msg);
			}

			img0_file = img0Files[nImgCount];
			frame0 = cvLoadImage(img0_file);
			img1_file = img1Files[nImgCount];
			frame1 = cvLoadImage(img1_file);

			if (frame0.empty())	break;
			if (frame1.empty())	break;

			// 复制图像
			img0 = frame0.clone();
			img1 = frame1.clone();

			// 检测角点
			bool flag = m_cameraCalibrator.detectCorners(img0, img1, cornerDatas, nImgCount);
			if (flag)
			{
				CString strSucceed;
				strSucceed.Format(_T("第%d张图像角点检测成功!"), nImgCount + 1);
				RunStateInfoShow(strSucceed);

				//使图像反色，表明同时找到完整的棋盘角点
				//bitwise_not(img0, img0);
				//bitwise_not(img1, img1);
				//将图片显示在窗口中;
				ShowImage(img0, IDC_PicLfCam);
				ShowImage(img1, IDC_PicRtCam);

				nImgCount++;
	
			}
			else
			{
				CString strFalseCorners;
				strFalseCorners.Format(_T("第%d张图像角点检测失败！"), nImgCount + 1);
				RunStateInfoShow(strFalseCorners);
				ShowImage(img0, IDC_PicLfCam);
				ShowImage(img1, IDC_PicRtCam);
				return;
			}
		}

		//开始标定计算
		m_CalibrationResult.dBoardWidth = m_nBoardWidth;
		m_CalibrationResult.dBoardHeight = m_nBoardHeight;
		m_CalibrationResult.dPixelSize = m_nPixelSize;
		m_CalibrationResult.dSquareSize = m_nSquareSize;

		RunStateInfoShow(_T("正在进行标定计算…"));
		m_cameraCalibrator.calibrateStereoCamera(cornerDatas, m_CalibrationResult);
	
		//获取标定时间;
		CString sCurrentTime;
		CTime ttii;
		ttii = CTime::GetCurrentTime();
		sCurrentTime = ttii.Format(_T("%Y年%m月%d日 %X"));
		m_CalibrationResult.strCalibrateTime = sCurrentTime;
		//显示标定参数;
		CString str;
		str.Empty();
		str.Format(_T("左相机焦距：%fmm"), m_CalibrationResult.dLeftCameraFocalLen);
		RunStateInfoShow(str);

		str.Empty();
		str.Format(_T("右相机焦距：%fmm"), m_CalibrationResult.dRightCameraFocalLen);
		RunStateInfoShow(str);

		str.Empty();
		str.Format(_T("标定误差：%fmm"), m_CalibrationResult.dCaliratebError);
		RunStateInfoShow(str);

		str.Empty();
		if (m_CalibrationResult.dCaliratebError < 0.8)
		{
			RunStateInfoShow(_T("标定成功！"));
		}
		else
		{
			RunStateInfoShow(_T("标定误差过大，建议重新标定！"));
		}

		str.Empty();
		str.Format(_T("标定时间：%s"), m_CalibrationResult.strCalibrateTime);
		RunStateInfoShow(str);

		//保存标定数据;
		m_CalibrationResult.sCaliResultFilePath.Format(_T("%s\\CalibrationResult"), GetAppExecPath());
		m_CalibrationResult.WriteYMLFile();
		
	}
	// 错误信息处理
	catch (LPCTSTR errMsg)
	{
		AfxMessageBox(errMsg);
	}
	catch (cv::Exception& e)
	{
		char err[2048];
		sprintf_s(err, "发生错误: %s", e.what());
		CString errInfo;
		errInfo = err;
		AfxMessageBox(_T(errInfo));
	}
	catch (...)
	{
		AfxMessageBox(_T("发生未知错误！"));
	}
	
	//恢复摄像机
	if (m_cameraInitFlag)
	{
		if (m_camType == Camera::CAM_TYPE::MIND)
		{
			//CameraPlay(m_hCamera[0]);
			//CameraPlay(m_hCamera[1]);
		}
		else if (m_camType == Camera::CAM_TYPE::UVC)
		{
			SetTimer(1, 50, NULL);	// 50ms 定时显示
		}
	}
}


void CStereoCameraDlg::OnBnClickedBnsetlfcam()
{
	// TODO: Add your control notification handler code here
	//if (m_hCamera[0] > 0)//判断相机是否打开
	//{
	//	CameraShowSettingPage(m_hCamera[0], TRUE);//"显示相机的属性配置窗口，该窗口由SDK内部生成";
	//}
}


void CStereoCameraDlg::OnBnClickedBnsetrtcam()
{
	// TODO: Add your control notification handler code here
	//if (m_hCamera[1] > 0)//判断相机是否打开
	//{
	//	CameraShowSettingPage(m_hCamera[1], TRUE);//"显示相机的属性配置窗口，该窗口由SDK内部生成";
	//}
}

/*
Mat* CStereoCameraDlg::Snapshot(int hCamera, int type)
{
	tSdkFrameHead FrameInfo;
	BYTE *pRawBuffer;
	BYTE *pRgbBuffer;
	CString sFileName;
	tSdkImageResolution sImageSize;
	CameraSdkStatus status;
	CString msg;

	if (hCamera < 1)//无效的相机句柄
	{
		return NULL;
	}

	memset(&sImageSize, 0, sizeof(tSdkImageResolution));
	sImageSize.iIndex = 0xff;
	//CameraSetResolutionForSnap设置抓拍时的分辨率，可以和预览时相同，也可以不同。
	//sImageSize.iIndex = 0xff; sImageSize.iWidth 和 sImageSize.iHeight 置0，表示抓拍时分辨率和预览时相同。
	//如果您希望抓拍时为单独的分辨率，请参考我们的Snapshot例程。或者参阅SDK手册中有关CameraSetResolutionForSnap接口的详细说明
	CameraSetResolutionForSnap(hCamera, &sImageSize);//"设置抓拍模式下的分辨率";

	//	CameraSnapToBuffer抓拍一帧图像数据到缓冲区中，该缓冲区由SDK内部申请,成功调用后，需要
	if ((status = CameraSnapToBuffer(hCamera, &FrameInfo, &pRawBuffer, 1000)) != CAMERA_STATUS_SUCCESS)
	{
		AfxMessageBox(_T("Snapshot failed,is camera in pause mode?"));
		return NULL;
	}
	else
	{

		//成功抓拍后，保存到文件
		CString msg;
		//char sCurpath[128];
		//GetCurrentDirectory(128, sCurpath);
		//CString strTime = CTime::GetCurrentTime().Format(_T("%Y%m%d%H%M%S"));
		
		CString oneFile = (hCamera == 1) ? "L" : "R";
		int imgCount = m_imgCount;
		CString saveType;

		//标定
		if (type ==1)
		{
			saveType = "calibrateImg";
		}
		else if (type == 2)
		{
			imgCount = 999;
			saveType = "snapImg";
		}

		sFileName.Format("%s\\%s\\%s_%d", m_workDir, saveType, oneFile, imgCount);//初始化保存文件的文件名

		//申请一个buffer，用来将获得的原始数据转换为RGB数据，并同时获得图像处理效果
		pRgbBuffer = (BYTE *)CameraAlignMalloc(FrameInfo.iWidth*FrameInfo.iHeight * 3, 16);
		//Process the raw data,and get the return image in RGB format
		CameraImageProcess(hCamera, pRawBuffer, pRgbBuffer, &FrameInfo);//处理图像，并得到RGB格式的数据";

		//Release the buffer which get from CameraSnapToBuffer or CameraGetImageBuffer
		CameraReleaseImageBuffer(hCamera, pRawBuffer);//"释放由CameraSnapToBuffer、CameraGetImageBuffer获得的图像缓冲区";

		//CameraSaveImage 保存图像，这里仅仅演示如何保存BMP图像。如果需要保存成其他格式的，里如果JPG,PNG,RAW等，
		//请参考我们的Snapshot例程。或者参阅SDK手册中有关CameraSaveImage接口的详细说明
		if ((status = CameraSaveImage(hCamera, sFileName.GetBuffer(1), pRgbBuffer, &FrameInfo, FILE_BMP, 100)) != CAMERA_STATUS_SUCCESS)
		{
			msg.Format("Failed to save image to [%s] ,please check the path", sFileName);
			RunStateInfoShow(_T(msg));
		}
		else
		{
			msg.Format("保存图片: [%s_%d.BMP]", oneFile, imgCount);
			RunStateInfoShow(_T(msg));
		}

		CameraAlignFree(pRgbBuffer);

		return NULL;
	}

}
*/

void CStereoCameraDlg::OnBnClickedBngrabbothcam()
{
	// TODO: Add your control notification handler code here
	if (m_cameraInitFlag)
	{
		if (m_camType == Camera::CAM_TYPE::MIND)
		{
			//Snapshot(m_hCamera[0], 1);
			//Snapshot(m_hCamera[1], 1);

		}
		else if (m_camType == Camera::CAM_TYPE::UVC)
		{
			Mat img_left, img_right;
			Mat frame = m_cameraSupport.getPicture();
			if (frame.empty())
			{
				return;
			}
			Size2i img_size(frame.cols / 2, frame.rows);
			img_left = frame(Rect(0, 0, img_size.width, img_size.height));
			img_right = frame(Rect(img_size.width, 0, img_size.width, img_size.height));

			CString calibImgPath;
			calibImgPath.Format("%s\\calibrateImg", m_workDir);
			if (!PathFileExists(calibImgPath))  //如果该路径不存在则新建该路径;
			{
				CreateDirectory(calibImgPath, NULL);
			}
			CString sFileName1, sFileName2;
			CString msg;
			sFileName1.Format("%s\\L_%d.jpg", calibImgPath, m_imgCount);//初始化保存文件的文件名
			sFileName2.Format("%s\\R_%d.jpg", calibImgPath, m_imgCount);//初始化保存文件的文件名

			imwrite(sFileName1.GetBuffer(0), img_left);
			imwrite(sFileName2.GetBuffer(0), img_right);

			msg.Format("保存图片成功!");
			RunStateInfoShow(_T(msg));
		}

		m_imgCount++;
	}

}


void CStereoCameraDlg::OnBnClickedBnruncam()
{
	// TODO: Add your control notification handler code here
	if (m_camType == Camera::CAM_TYPE::MIND)
	{
		//CameraPlay(m_hCamera[0]);//"开始预览";
		//CameraPlay(m_hCamera[1]);//"开始预览";
		//m_cameraInitFlag = true;
	}
	else if (m_camType == Camera::CAM_TYPE::UVC)
	{
		bool cam_booluvc = m_cameraSupport.CameraInit(Camera::CAM_TYPE::UVC, m_CameraSelectID);
		if (!cam_booluvc)
		{
			RunStateInfoShow(_T("启动摄像头失败！"));
			return;
		}
		m_cameraInitFlag = true;
		SetTimer(1, 50, NULL);	// 50ms 定时显示
	}
}


void CStereoCameraDlg::OnBnClickedBnDefaultcamcalibparam()
{
	// TODO: Add your control notification handler code here
	m_nBoardWidth = 7;
	m_nBoardHeight = 5;
	m_nSquareSize = 21.6;
	m_nPixelSize = 0.0036;
	UpdateData(FALSE);
}
    
void CStereoCameraDlg::OnBnClickedBnsavecalibparams()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_CalibrationResult.dBoardHeight = m_nBoardHeight;
	m_CalibrationResult.dBoardWidth = m_nBoardWidth;
	m_CalibrationResult.dSquareSize = m_nSquareSize;
	m_CalibrationResult.dPixelSize = m_nPixelSize;
	m_CalibrationResult.WriteYMLFile();

	RunStateInfoShow(_T("保存参数成功！"));
}

void CStereoCameraDlg::OnTimer(UINT nIDEvent) //实时绘制场景 
{
	// TODO: Add your message handler code here and/or call default 
	switch (nIDEvent)
	{
	case 1:
		if (m_camType == Camera::CAM_TYPE::UVC)
		{
			Mat img_left, img_right;
			Mat frame = m_cameraSupport.getPicture();
			if (frame.empty())
			{
				return;
			}
			Size2i img_size(frame.cols / 2, frame.rows);
			img_left = frame(Rect(0, 0, img_size.width, img_size.height));
			img_right = frame(Rect(img_size.width, 0, img_size.width, img_size.height));

			ShowImage(img_left, IDC_PicLfCam);
			ShowImage(img_right, IDC_PicRtCam);
		}
		break;
	case 2:

		break;
	}
	
	CDialogEx::OnTimer(nIDEvent);
}

BEGIN_EVENTSINK_MAP(CStereoCameraDlg, CDialogEx)
	ON_EVENT(CStereoCameraDlg, IDC_TCHART2, 20, CStereoCameraDlg::OnMouseMoveTchart2, VTS_I4 VTS_I4 VTS_I4)
END_EVENTSINK_MAP()


void CStereoCameraDlg::OnMouseMoveTchart2(long Shift, long X, long Y)
{
	// TODO: Add your message handler code here

	int mPoint = -1;
	CSeries series = (CSeries)m_chart2.Series(0);
	double xValue = series.XScreenToValue(X) + 0.5;
	mPoint = (int)(xValue);
	if (mPoint < 0)
	{
		return;
	}

	double posX = m_chart2.GetAxis().GetBottom().CalcPosPoint(X);
	double posY = m_chart2.GetAxis().GetLeft().CalcPosPoint(Y);

	CToolList tlist = m_chart2.GetTools();
	CTools tools = tlist.GetItems(0);
	CAnnotationTool anntool = tools.GetAsAnnotation();
	CString strTopNote;
	strTopNote.Format("Z: %f mm \n Y: %f mm \n ", posX, posY);
	anntool.SetText(strTopNote);
}


void CStereoCameraDlg::OnBnClickedBnbw()
{
	// TODO: Add your control notification handler code here
	//vector<Point3d> real_points;
	m_calRadBN = GetCheckedRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg);
	Mat matchCenter;
	//判断是否是在线模式
	if (m_calRadBN == IDC_RAD_CalcFromCam)
	{
		//Mat frame_left = cv::Mat(m_sFrInfo[0].iHeight, m_sFrInfo[0].iWidth, CV_8UC3, m_pFrameBuffer[0]);
		//Mat frame_right = cv::Mat(m_sFrInfo[1].iHeight, m_sFrInfo[1].iWidth, CV_8UC3, m_pFrameBuffer[1]);

		////反转矩阵
		//Mat t1, t2;
		//cv::flip(frame_left, t1, 0);
		//cv::flip(frame_right, t2, 0);

		//RunStateInfoShow(_T("正在进行测距计算..."));
		//m_measureDist.BWcaculateDistance(t1, t2, m_CalibrationResult, real_points);

	}
	else
	{

		vector<CStringA> imgFirst;
		const char* first_file = NULL, *second_file = NULL;

		imgFirst = DoSelectFiles(
			_T("*.bmp"),
			OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
			_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
			_T("选择两张图像文件"),
			_T("Imgs\\Left"));

		if (imgFirst.empty() || imgFirst.size() < 2 || imgFirst.size() > 2)	// 判断输入图片
		{
			AfxMessageBox(_T("请选择两张图像！"));
			return;
		}
		first_file = imgFirst[0];
		second_file = imgFirst[1];

		Mat Mode_left = cvLoadImage(first_file); 
		Mat Mode_right = cvLoadImage(second_file);

		vector<CStringA> imgFiles;
		const char* img0_file = NULL, *img1_file = NULL;

		imgFiles = DoSelectFiles(
			_T("*.bmp"),
			OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
			_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
			_T("选择两张图像文件"),
			_T("Imgs\\Left"));

		if (imgFiles.empty() || imgFiles.size() < 2 || imgFiles.size() > 2)	// 判断输入图片
		{
			AfxMessageBox(_T("请选择两张图像！"));
			return;
		}
		RunStateInfoShow(_T("正在进行测距计算..."));
		img0_file = imgFiles[0];
		img1_file = imgFiles[1];

		Mat frame_left = cvLoadImage(img0_file);
		Mat frame_right = cvLoadImage(img1_file);

		ShowImage(frame_left, IDC_PicLfCam);
		ShowImage(frame_right, IDC_PicRtCam);
		m_measureDist.BWcaculateDistance(Mode_left, Mode_right, frame_left, frame_right, m_CalibrationResult, m_realPoints, matchCenter);

	}

	ofstream fout2("real_pointsNew.txt");
	for (int i = 0; i != m_realPoints.size(); i++)
	{
		Point3d p = m_realPoints[i];
		fout2 << p.x << "," << p.y << "," << p.z << endl;
	}

	//
	//修正的摄像机旋转矩阵
	Mat_<double> rotateMat = m_rotateMat.inv();

	vector<double> ylist;
	vector<double> zlist;
	CSeries lineSeries = (CSeries)m_chart2.Series(0);
	lineSeries.Clear();
	
	for (int i = 0; i != m_realPoints.size(); i++)
	{
		Point3d p = m_realPoints[i];
		if (p.z < 0 || p.z >1500)
		{
			continue;
		}

		//method 2， 直接旋转
		p.y = -1.0 * p.y;
		double tmp_y = p.y*rotateMat(1, 1) + p.z*rotateMat(1, 2);
		double tmp_z = p.y*rotateMat(2, 1) + p.z*rotateMat(2, 2);
		p.y = tmp_y;
		p.z = tmp_z;
				
		lineSeries.AddXY(p.z, p.y + m_CameraHeigh, NULL, NULL);

		//过滤噪声点
		if (p.z > 600 && p.z < 1200)
		{
			ylist.push_back(p.y);
			zlist.push_back(p.z);
		}
	}
	//分别排序，得到最大z，最高y
	sort(ylist.begin(), ylist.end(), [](double a, double b){return a > b; });
	sort(zlist.begin(), zlist.end());

	//取平均数
	double ymax = 0, zmin = 0;
	if (ylist.size() > 3 && zlist.size() > 3)
	{
		for (int i = 0; i < 3; i++)
		{
			ymax += ylist[i];
			zmin += zlist[i];
		}
		ymax /= 3;
		zmin /= 3;
	}
	//因为在相机坐标下y有负值，所以要加上相机的高度，修正y值
	ymax = m_CameraHeigh + ymax;
	CString rtValue;
	rtValue.Format("Value: yMax =%f , zMin =%f .", ymax, zmin);
	RunStateInfoShow(rtValue);
}


void CStereoCameraDlg::OnBnClickedBnxiuzheng()
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	vector<CStringA> imgFile;
	imgFile = DoSelectFiles(
		_T("*.bmp"),
		OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
		_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
		_T("选择1张图像文件"),
		_T("Imgs\\"));

	Mat img = imread(imgFile[0].GetBuffer(0));

	vector<cv::Point3f> obj_points;
	for (int i = 0; i < m_CalibrationResult.dBoardHeight; i++)
	{
		for (int j = 0; j < m_CalibrationResult.dBoardWidth; j++)
		{
			Point3f realPoint(i*m_CalibrationResult.dSquareSize, j*m_CalibrationResult.dSquareSize, 0);
			obj_points.push_back(realPoint);
		}
	}
	
	vector<cv::Point2f> corners(m_CalibrationResult.dBoardWidth*m_CalibrationResult.dBoardHeight,Point2f(0.0,0.0));
	findChessboardCorners(img, cv::Size2i(m_CalibrationResult.dBoardWidth, m_CalibrationResult.dBoardHeight), corners);

	if (corners.empty())
	{
		RunStateInfoShow(_T("检测角点失败..."));
		return;
	}

	int board_n = m_CalibrationResult.dBoardWidth*m_CalibrationResult.dBoardHeight;
	CvMat* image_points = cvCreateMat(board_n, 2, CV_32FC1);
	CvMat* object_points = cvCreateMat(board_n, 3, CV_32FC1);
	CvMat intrinsic = m_CalibrationResult.mLeftCameraInParas;
	CvMat distortion = m_CalibrationResult.mLeftCameraDistorParas;
	CvMat* rotation_vector = cvCreateMat(3, 1, CV_32FC1);
	CvMat* translation_vector = cvCreateMat(3, 1, CV_32FC1);
	CvMat* rotation_mat = cvCreateMat(3, 3, CV_32FC1);

	for (int i = 0; i < board_n; ++i)
	{
		CV_MAT_ELEM(*image_points, float, i, 0) = corners[i].y;
		CV_MAT_ELEM(*image_points, float, i, 1) = corners[i].x;
		CV_MAT_ELEM(*object_points, float, i, 0) = obj_points[i].x;
		CV_MAT_ELEM(*object_points, float, i, 1) = obj_points[i].y;
		CV_MAT_ELEM(*object_points, float, i, 2) = obj_points[i].z;
	}

	//计算外参
	cvFindExtrinsicCameraParams2(object_points, image_points, &intrinsic, &distortion, rotation_vector, translation_vector);
	cvRodrigues2(rotation_vector, rotation_mat);
	m_rotateMat = Mat(rotation_mat, true);
	m_translateMat = Mat(translation_vector, true);

	m_CalibrationResult.amendRotMat = m_rotateMat;
	m_CalibrationResult.dCameraHeigh = m_CameraHeigh;
	m_CalibrationResult.WriteYMLFile();

	RunStateInfoShow(_T("已保存修正参数。"));

}


void CStereoCameraDlg::OnBnClickedBnreadfrommatlab()
{
	// TODO: Add your control notification handler code here
	//读取内部参数   
	CString Left_Intrinsics_File;
	Left_Intrinsics_File.Format(_T("%s\\Intrinsics_Camera_Left.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString Right_Intrinsics_File;
	Right_Intrinsics_File.Format(_T("%s\\Intrinsics_Camera_Right.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString Left_Distortion_File;
	Left_Distortion_File.Format(_T("%s\\Distortion_Camera_Left.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString Right_Distortion_File;
	Right_Distortion_File.Format(_T("%s\\Distortion_Camera_Right.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString Translation_File;
	Translation_File.Format(_T("%s\\Translation.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString RotRodrigues_File;
	RotRodrigues_File.Format(_T("%s\\RotRodrigues.xml"), m_CalibrationResult.sCaliResultFilePath);


	CvMat *Intrinsics_Camera_Left = (CvMat *)cvLoad(Left_Intrinsics_File);
	CvMat *Intrinsics_Camera_Right = (CvMat *)cvLoad(Right_Intrinsics_File);
	CvMat *Distortion_Camera_Left = (CvMat *)cvLoad(Left_Distortion_File);
	CvMat *Distortion_Camera_Right = (CvMat *)cvLoad(Right_Distortion_File);
	CvMat *Translation_matlab = (CvMat *)cvLoad(Translation_File);
	CvMat *RotRodrigues_matlab = (CvMat *)cvLoad(RotRodrigues_File);
	CvMat *R_opencv = cvCreateMat(3, 3, CV_32F);
	cvRodrigues2(RotRodrigues_matlab, R_opencv);

	m_CalibrationResult.mLeftCameraInParas = Intrinsics_Camera_Left;
	m_CalibrationResult.mLeftCameraDistorParas = Distortion_Camera_Left;
	m_CalibrationResult.mRightCameraInParas = Intrinsics_Camera_Right;
	m_CalibrationResult.mRightCameraDistorParas = Distortion_Camera_Right;
	m_CalibrationResult.mL2RRotation = RotRodrigues_matlab;
	m_CalibrationResult.mL2RRotation33 = R_opencv;
	m_CalibrationResult.mL2RTranslation = Translation_matlab;

	CString leftPointsFile;
	leftPointsFile.Format(_T("%s\\x_left_1.xml"), m_CalibrationResult.sCaliResultFilePath);
	CString rightPointsFile;
	rightPointsFile.Format(_T("%s\\x_right_1.xml"), m_CalibrationResult.sCaliResultFilePath);
	CvMat *leftPoints = (CvMat *)cvLoad(leftPointsFile);
	CvMat *rightPoints = (CvMat *)cvLoad(rightPointsFile);
	Mat p1, p2;
	transpose(Mat(leftPoints), p1);
	transpose(Mat(rightPoints), p2);
	Mat F = findFundamentalMat(p1, p2,FM_RANSAC, 1, 0.99);
	m_CalibrationResult.mFoundational = F;

	m_CalibrationResult.WriteYMLFile();

	RunStateInfoShow(_T("读入matlab标定参数成功！"));
}


void CStereoCameraDlg::OnCbnSelchangeCameraselect()
{
	// TODO: Add your control notification handler code here
	int nsel;
	CString str;
	nsel = m_CameraSelectCombox.GetCurSel();
	m_CameraSelectCombox.GetLBText(nsel, str);
	m_CameraSelect = str;
	m_CameraSelectID = nsel;

	m_camType = Camera::CAM_TYPE::UVC;
}


void CStereoCameraDlg::DrawPic(CDC *pDC, CRect &rectPicture)
{
	//确定图象显示大小
	int width = rectPicture.Width();
	int height = rectPicture.Height();
	const int margin = 5;

	if (m_realPoints.empty())
		return;

	//修正的摄像机旋转矩阵
	Mat_<double> rotateMat = m_rotateMat.inv();
	vector<double> ylist;
	vector<double> xlist;
	vector<Point2f> point2D;
	for (int i = 0; i != m_realPoints.size(); i++)
	{
		Point3d p = m_realPoints[i];
		//过滤
		if (p.z < 0 || p.z >1500)
		{
			continue;
		}
		p.y = -1.0 * p.y;
		double tmp_y = p.y*rotateMat(1, 1) + p.z*rotateMat(1, 2);
		double tmp_z = p.y*rotateMat(2, 1) + p.z*rotateMat(2, 2);
		p.y = tmp_y;
		p.z = tmp_z;

		//过滤噪声点
		if (p.z > 400 && p.z < 800)
		{
			ylist.push_back(p.y);
			xlist.push_back(p.z); 
			point2D.push_back(Point2f(p.z, p.y));
		}
	}
	//分别排序，得到最大z，最高y
	sort(ylist.begin(), ylist.end());
	sort(xlist.begin(), xlist.end());  

	minX = xlist[0]-margin;  
	maxX = xlist[xlist.size() - 1]+margin;  
	minY = ylist[0]-margin;
	maxY = ylist[ylist.size() - 1]+margin;

	//确定X，Y轴每单位显示宽度 
	intervalX = (width - myleft - myright) / (maxX - minX);
	intervalY = (height - mybottom - mytop) / (maxY - minY);
	//绘制X，Y轴
	//X轴从图形区域最左端到最右端
	pDC->MoveTo(int(myleft), int(height - mybottom));
	pDC->LineTo(int(width - myright), int(height - mybottom));
	//Y轴从图形区域最底端到最顶端
	pDC->MoveTo(int(myleft), int(height - mybottom));
	pDC->LineTo(int(myleft), int(mytop));

	//确定显示刻度个数
	const int count = 5;
	//确定每个显示刻度之间的宽度
	float spaceX = (width - myleft - myright) / count;
	float spaceY = (height - mybottom - mytop) / count;
	//绘制刻度和刻度值
	CString str;
	//X轴
	for (int i = 0; i <= count; i++)
	{
		str.Format("%.1f", minX + i*(maxX - minX) / count);
		pDC->MoveTo(int(myleft + spaceX*i), int(height - mybottom));
		pDC->LineTo(int(myleft + spaceX*i), int(height - (mybottom + 5)));
		pDC->TextOut(int(myleft + spaceX*i - 10),
			int(height - (mybottom - 5)), str);
	}
	//Y轴
	for (int i = 0; i <= count; i++)
	{
		str.Format("%.1f", minY + i*(maxY - minY) / count);
		pDC->MoveTo(int(myleft), int(height - (mybottom + spaceY*i)));
		pDC->LineTo(int(myleft + 5), int(height - (mybottom + spaceY*i)));
		pDC->TextOut(int(myleft - 50), int(height - (mybottom + spaceY*i + 8)), str);
	}

	//绘制数据点
	for (int i = 0; i != point2D.size(); i++)
	{
		Point2f p = point2D[i];
		int x = myleft + (p.x - minX)*intervalX;
		int y = height - (mybottom + (p.y - minY)*intervalY);
		pDC->MoveTo(x,y);
		pDC->SetPixel(x, y,RGB(255,0,0));
	}

	//绘制X，Y轴的变量名
	pDC->TextOut(width / 2, height - 20, "Z轴(深度)");
	pDC->TextOut(0, height / 2, "Y轴(高度)");
}

void CStereoCameraDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	ClientToScreen(&point);
	CRect rect;
	GetDlgItem(IDC_PicDraw)->GetClientRect(rect);
	GetDlgItem(IDC_PicDraw)->ClientToScreen(rect);
	CDC *pDC = GetDlgItem(IDC_PicDraw)->GetDC();
	 
	if (rect.PtInRect(point))
	{
		int x = point.x - rect.left;
		int y = point.y - rect.top;
		float Z = (x - myleft) / intervalX + minX;
		float Y = ((rect.Height() - y) - mybottom) / intervalY + minY;

		CString str;
		str.Format(" z=%f \r\n y=%f", Z, Y);
		GetDlgItem(IDC_VALUE)->SetWindowTextA(_T(str));

		//CPen newPen;
		//CPen* oldPen;
		//CBrush newBrush;   
		//CBrush* pOldBrush;

		//newBrush.CreateSolidBrush(RGB(255, 255, 255));
		//pOldBrush = pDC->SelectObject(&newBrush); 
		//pDC->Rectangle(rect);
		//pDC->SelectObject(pOldBrush);
		//newBrush.DeleteObject();
		//
		//newPen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
		//oldPen = pDC->SelectObject(&newPen);

		//m_picDraw.ShowWindow(FALSE);
		//m_picDraw.ShowWindow(TRUE);
		//DrawPic(pDC, rect);

		//m_mousePoint = CPoint(x,y);
		//pDC->MoveTo(0, y);
		//pDC->LineTo(rect.Width(), y);
		//pDC->MoveTo(x, 0);
		//pDC->LineTo(x, rect.Height());
		
		//pDC->SelectObject(oldPen);
		//newPen.DeleteObject();
	}
	
	CDialogEx::OnMouseMove(nFlags, point);
}



void CStereoCameraDlg::OnBnClickedBncalculate()
{
	// TODO: Add your control notification handler code here
	try{
		//计算算法时间
		clock_t start, finish;
		start = clock();
		//vector<Point3d> real_points;
		m_realPoints.clear();
		m_calRadBN = GetCheckedRadioButton(IDC_RAD_CalcFromCam, IDC_RAD_CalcFromImg);
		Mat leftCenter, rightCenter;
		Mat matchCenter;
		//判断是否是在线模式
		if (m_calRadBN == IDC_RAD_CalcFromCam)
		{
			/*
			if (m_camType == Camera::CAM_TYPE::MIND)
			{
			Mat frame_left = cv::Mat(m_sFrInfo[0].iHeight, m_sFrInfo[0].iWidth, CV_8UC3, m_pFrameBuffer[0]);
			Mat frame_right = cv::Mat(m_sFrInfo[1].iHeight, m_sFrInfo[1].iWidth, CV_8UC3, m_pFrameBuffer[1]);
			//反转矩阵
			Mat t1, t2;
			cv::flip(frame_left, t1, 0);
			cv::flip(frame_right, t2, 0);

			RunStateInfoShow(_T("正在进行测距计算..."));
			m_measureDist.caculateDistance(t1, t2, m_CalibrationResult, m_realPoints);

			}
			*/
			if ((m_camType == Camera::CAM_TYPE::UVC))
			{
				Mat frame = m_cameraSupport.getPicture();
				Size2i img_size(frame.cols / 2, frame.rows);
				Mat img_left = frame(Rect(0, 0, img_size.width, img_size.height));
				Mat img_right = frame(Rect(img_size.width, 0, img_size.width, img_size.height));

				RunStateInfoShow(_T("正在进行测距计算..."));
				m_measureDist.caculateDistance(img_left, img_right, m_CalibrationResult, m_realPoints, leftCenter, rightCenter, matchCenter);
			}
		}
		else
		{
			vector<CStringA> imgFiles;
			const char* img0_file = NULL, *img1_file = NULL;

			imgFiles = DoSelectFiles(
				_T("*.bmp"),
				OFN_ENABLESIZING | OFN_EXPLORER | OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,
				_T("image files (*.bmp; *.png; *.jpg) |*.bmp; *.png; *.jpg; *.jpeg| All Files (*.*) |*.*||"),
				_T("选择两张图像文件"),
				_T("Imgs\\Left"));

			if (imgFiles.empty() || imgFiles.size() < 2 || imgFiles.size() > 2)	// 判断输入图片
			{
				AfxMessageBox(_T("请选择两张图像！"));
				return;
			}
			RunStateInfoShow(_T("正在进行测距计算..."));
			img0_file = imgFiles[0];
			img1_file = imgFiles[1];

			Mat frame_left = cvLoadImage(img0_file);
			Mat frame_right = cvLoadImage(img1_file);

			ShowImage(frame_left, IDC_PicLfCam);
			ShowImage(frame_right, IDC_PicRtCam);
			m_measureDist.caculateDistance(frame_left, frame_right, m_CalibrationResult, m_realPoints, leftCenter, rightCenter, matchCenter);

		}

		//保存得到的三维坐标
		ofstream fout2("real_pointsNew.txt");
		for (int i = 0; i != m_realPoints.size(); i++)
		{
			Point3d p = m_realPoints[i];
			fout2 << p.x << "," << p.y << "," << p.z << endl;
		}
		//显示中间过程
		ShowImage(leftCenter, IDC_LeftCenterPic);
		ShowImage(rightCenter, IDC_RightCenterPic);
		ShowImage(matchCenter, IDC_MatchPic);


		//测试用例 ，摄像机旋转20度
		double theta = 10.0 / 180 * M_PI;
		double dat[] = { 1, 0, 0, 0, cos(theta), -1*sin(theta), 0, sin(theta), cos(theta) };
		Matx33d rotateMat(dat);

		//method 1  
		//double theta2 = -1.0 * theta;
		//double l1[] = {tan(theta2), -1};
		//double l2[] = {tan(M_PI/2.0+theta2), -1};

		//修正的摄像机旋转矩阵
		//Mat_<double> rotateMat = m_rotateMat.inv();

		vector<double> ylist;
		vector<double> zlist;
		CSeries lineSeries = (CSeries)m_chart2.Series(0);
		lineSeries.Clear();

		for (int i = 0; i != m_realPoints.size(); i++)
		{
			Point3d p = m_realPoints[i];
			//过滤
			if (p.z < 0 || p.z >1500)
			{
				continue;
			}

			//method 1，用点到直线距离
			//p.y = -1.0 * p.y;
			//double d_l1 = -1.0* (l1[0] * p.z + l1[1] * p.y) / sqrt(l1[0] * l1[0] + l1[1] * l1[1]);
			//double d_l2 = abs(l2[0] * p.z + l2[1] * p.y) / sqrt(l2[0] * l2[0] + l2[1] * l2[1]);
			//p.y = d_l1;
			//p.z = d_l2;

			////method 2， 直接旋转
			p.y = -1.0 * p.y;
			double tmp_y = p.y*rotateMat(1, 1) + p.z*rotateMat(1, 2);
			double tmp_z = p.y*rotateMat(2, 1) + p.z*rotateMat(2, 2);
			p.y = tmp_y;
			p.z = tmp_z;


			//过滤噪声点
			if (p.z > 600 && p.z < 900)
			{
				lineSeries.AddXY(p.z, p.y + m_CameraHeigh, NULL, NULL);
				ylist.push_back(p.y);
				zlist.push_back(p.z);
			}
		}
		//分别排序，得到最大z，最高y
		double ymax = 0, zmin = 0;
		if (!ylist.empty() && !zlist.empty())
		{
			sort(ylist.begin(), ylist.end());
			sort(zlist.begin(), zlist.end());

			CRect rectPicture;
			m_picDraw.GetClientRect(&rectPicture);
			DrawPic(m_picDraw.GetDC(), rectPicture);

			ymax = ylist[ylist.size() - 1];
			zmin = zlist[0];
		}

		//因为在相机坐标下y有负值，所以要加上相机的高度，修正y值
		ymax = m_CameraHeigh + ymax;
		CString rtValue;
		rtValue.Format("Value: yMax =%f , zMin =%f .", ymax, zmin);
		RunStateInfoShow(rtValue);

		finish = clock();
		CString stime;
		stime.Format("Time : %f ms", 1000.0*(finish - start) / (double)CLOCKS_PER_SEC);
		RunStateInfoShow(stime);
	}

	// 错误信息处理
	catch (LPCTSTR errMsg)
	{
		AfxMessageBox(errMsg);
	}
	catch (cv::Exception& e)
	{
		char err[2048];
		sprintf_s(err, "发生错误: %s", e.what());
		CString errInfo;
		errInfo = err;
		AfxMessageBox(_T(errInfo));
	}
	catch (...)
	{
		AfxMessageBox(_T("发生未知错误！"));
	}

}
