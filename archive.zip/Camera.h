#pragma once
#include "CameraDS.h"
//#include "CameraApi.h"
#include <map>
#include <string>
#include <opencv2/opencv.hpp>
using namespace cv;
using namespace std;

class Camera
{

private:
	int upCameraCode;
	int downCameraCode;
	VideoCapture capture;
	Mat frame;

	//DirectShow
	CCameraDS camDs;
	//int cam_count;

public:
	Camera();
	~Camera();

	enum CAM_TYPE{ MIND = 1, UVC = 2 };

	bool CameraInit(int type, int deviceid = 0);
	void CameraPlay();
	void CameraPause();
	Mat getPicture();
	
};

