// MainDialog.cpp : implementation file
//

#include "stdafx.h"
#include "StereoCamera.h"
#include "MainDialog.h"
#include "afxdialogex.h"


// CMainDialog dialog

IMPLEMENT_DYNAMIC(CMainDialog, CDialogEx)

CMainDialog::CMainDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMainDialog::IDD, pParent)
{

}

CMainDialog::~CMainDialog()
{
}

void CMainDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TCHART1, m_chart3);
}


BEGIN_MESSAGE_MAP(CMainDialog, CDialogEx)
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_BUTTON2, &CMainDialog::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BNCaculateMain, &CMainDialog::OnBnClickedBncaculatemain)
END_MESSAGE_MAP()


// CMainDialog message handlers

BOOL CMainDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	//��ȡ����·��
	m_workDir = GetAppExecPath();

	//��ȡ�궨����;
	m_CalibrationResult.sCaliResultFilePath.Format(_T("%s\\CalibrationResult"), m_workDir);
	m_CalibrationResult.bIsBinocularCameraCalibration = 1;
	bool bCaliSucflag = m_CalibrationResult.ReadYMLFile();

	//Ĭ�ϱ궨���������ļ��ж�ȡ
	m_CameraHeigh = m_CalibrationResult.dCameraHeigh;
	m_rotateMat = m_CalibrationResult.amendRotMat;

	if (!m_camera.CameraInit(Camera::CAM_TYPE::UVC))
	{
		AfxMessageBox(_T("Camera init fault!"));
	}


	return TRUE;
}

void CMainDialog::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	// TODO: Add your message handler code here and/or call default
	// ����С���������������ó���ͬ��ֵʹ���ڴ�С���ܸı�
	lpMMI->ptMinTrackSize.x = 480; // �趨��С���ٿ���
	lpMMI->ptMinTrackSize.y = 800; // �趨��С���ٸ߶�
	lpMMI->ptMaxTrackSize.x = 480; // �趨�����ٿ���
	lpMMI->ptMaxTrackSize.y = 800; // �趨�����ٸ߶�
	CDialogEx::OnGetMinMaxInfo(lpMMI);
}


void CMainDialog::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	CStereoCameraDlg dlg;
	dlg.DoModal();
	m_CalibrationResult = m_stereDlg.m_CalibrationResult;
	m_CameraHeigh = m_CalibrationResult.dCameraHeigh;
	m_rotateMat = m_CalibrationResult.amendRotMat;

}


/*----------------------------------
* ���� :	��ȡ��������ʱ���ڵ��ļ���·��
*----------------------------------
* ���� :	CStereoVisionDlg::F_GetAppExecPath
* ���� :	private
* ���� :	��������ʱ���ڵ��ļ���·��
*/
CString CMainDialog::GetAppExecPath()
{
	CString strPath;
	TCHAR path[_MAX_PATH];
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	::GetModuleFileName(AfxGetApp()->m_hInstance, path, _MAX_PATH);
	_tsplitpath(path, drive, dir, fname, ext);

	strPath.Empty();
	strPath += CString(drive);
	strPath += CString(dir);

	return strPath;
}


void CMainDialog::OnBnClickedBncaculatemain()
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	//m_camera.CameraInit(Camera::CAM_TYPE::UVC);
	Mat img_left, img_right;
	Mat frame = m_camera.getPicture();
	Mat leftCenter, rightCenter;
	Mat matchCenter;
	if (frame.empty())
	{
		return;
	}
	Size2i img_size(frame.cols / 2, frame.rows);
	img_left = frame(Rect(0, 0, img_size.width, img_size.height));
	img_right = frame(Rect(img_size.width, 0, img_size.width, img_size.height));

	vector<Point3d> real_points;
	m_measureDist.caculateDistance(img_left, img_right, m_CalibrationResult, real_points, leftCenter, rightCenter, matchCenter);

	//�������������ת����
	Mat_<double> rotateMat = m_rotateMat;
	rotateMat(1, 2) = rotateMat(1, 2)*(-1);
	rotateMat(2, 2) = rotateMat(2, 2)*(-1);

	vector<double> ylist;
	vector<double> zlist;
	CSeries lineSeries = (CSeries)m_chart3.Series(0);
	lineSeries.Clear();

	for (int i = 0; i != real_points.size(); i++)
	{
		Point3d p = real_points[i];
		if (p.z < 0 || p.z >1500)
		{
			continue;
		}

		//��������
		p.y = -1.0 * p.y;
		double tmp_y = p.y*rotateMat(1, 1) + p.z*rotateMat(1, 2);
		double tmp_z = p.y*rotateMat(2, 1) + p.z*rotateMat(2, 2);
		p.y = tmp_y;
		p.z = tmp_z;

		lineSeries.AddXY(p.z, p.y + m_CameraHeigh, NULL, NULL);

		//����������
		if (p.z > 600 && p.z < 1200)
		{
			ylist.push_back(p.y);
			zlist.push_back(p.z);
		}
	}
}
