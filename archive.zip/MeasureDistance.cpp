

#include "stdafx.h"
#include "MeasureDistance.h"



MeasureDistance::MeasureDistance()
{
}

MeasureDistance::~MeasureDistance()
{
}


void MeasureDistance::color_filter(Mat src, Mat& dst, vector<Point2f>& red_points)
{
	cvtColor(src, dst, CV_BGR2HSV);
	int rows = src.rows;
	int nc = src.cols * src.channels();

	for (int i = 0; i < rows; i++)
	{
		uchar* ptr = dst.ptr<uchar>(i);
		for (int j = 0; j < nc - 3; j += 3)
		{
			//����H������0<H<10,��160<H<180����Ϊ��ɫ
			if ((ptr[j] > 0 && ptr[j] < 10) || (ptr[j]>160 && ptr[j] < 180))
				continue;
			//����S������ȥ����ɫ����һ��S< Ϊ��ɫ��
			if (ptr[j + 1] > 60)
				continue;

			////����V������ȥ����������
			if (ptr[j + 2] > 46 && ptr[j + 2] < 220)
				continue;

			ptr[j] = 0;
			ptr[j + 1] = 0;
			ptr[j + 2] = 0;

			Point p(j / 3, i);
			red_points.push_back(p);
		}
	}

	cvtColor(dst, dst, CV_HSV2BGR);
	//imshow("1", dst);
	//waitKey();

}




float MeasureDistance::getThresh(vector<float>& vData)
{
	if (vData.empty())
	{
		return 0;
	}

	float fMeanAll = 0.0;
	for (int i = 0; i < vData.size(); ++i)
	{
		fMeanAll = fMeanAll + vData[i];
	}
	fMeanAll = fMeanAll / vData.size();

	float fMeanMin = 0.0;
	int nMinNum = 0;
	for (int i = 0; i < vData.size(); ++i)
	{
		if (vData[i] < fMeanAll)
		{
			fMeanMin = fMeanMin + vData[i];
			nMinNum++;
		}
	}
	fMeanMin = fMeanMin / nMinNum;
	//return fMeanAll; //find error. 
	return fMeanMin;  
}

bool MeasureDistance::DetectLinerCenterHor(cv::Mat &src, cv::Mat &dst, vector<cv::Point2f>& vSubCenterPoint)
{
	//ͼ��Ԥ����;
	vSubCenterPoint.clear();
	cv::Mat Image, imagegray;
	Image = src.clone();
	//Image=cv::imread("1.bmp",1);
	const int Width = Image.cols;
	const int Height = Image.rows;
	int Ilow = 40;   //��ǰ�Ҷ���ֵ
	int Ihigh = 150; //���ڻҶȲ���ֵ
	int BandWidth = 15; // 1/2�������
	if (src.channels() == 3)
	{
		cvtColor(src, imagegray, CV_BGR2GRAY);
	}
	else
	{
		imagegray = src.clone();
	}

	medianBlur(imagegray, imagegray, 3);
	
	//��ȡ����Ĵ�������λ��;
	//���ȣ�1*3�������ڣ���ҶȺ�
	int nWindowSize = 3;
	vector<int> Bool(Height, 0);
	//int *Bool=new int [Height];//���������жϸ����Ƿ��м�����
	//double **GrayAdd = new double*[Height];
	vector<vector<int> > GrayAdd(Height);
	for (int i = 0; i < Height; ++i)
		GrayAdd[i].resize(Width, 0);

	//for (int i = 0; i < Height; i++)
	//{
	//	for (int j = 1; j<Width - 1; j++)
	//	{
	//		if (imagegray.at<uchar>(i, j)>Ilow)
	//		{
	//			float aa = abs(imagegray.at<uchar>(i, j) - imagegray.at<uchar>(i, j - 1));
	//			float bb = abs(imagegray.at<uchar>(i, j) - imagegray.at<uchar>(i, j + 1));

	//			if ((aa < Ihigh) && (bb < Ihigh))
	//			{
	//				GrayAdd[i][j] = imagegray.at<uchar>(i, j - 1) + imagegray.at<uchar>(i, j) + imagegray.at<uchar>(i, j + 1);
	//				Bool[i] = 1;
	//			}
	//		}
	//	}
	//}
	////�ҳ��ҶȺ����λ��,��Ϊ��������λ��;
	//cv::Mat ImgCenter = cv::Mat::zeros(Height, Width, CV_8UC1);
	//int *C = new int[Height];//����洢ÿ������λ��;
	//for (int i = 0; i < Height; i++)
	//{
	//	double m = GrayAdd[i][0];
	//	C[i] = 0;
	//	for (int j = 1; j < Width - 1; j++)
	//	{
	//		if (m <= GrayAdd[i][j])
	//		{
	//			m = GrayAdd[i][j];
	//			C[i] = j;
	//		}
	//	}
	//}

	//�ҳ��ҶȺ����λ��,��Ϊ��������λ��;
	vector<int> C(Height);//����洢ÿ������λ��;
	for (int i = 0; i < Height; i++)
	{
		uchar* img_row = imagegray.ptr<uchar>(i);
		C[i] = 0;
		double row_max = 0;
		int idx_left = 0;
		int idx_right = 0;

		for (int j = BandWidth; j < Width - BandWidth; j++)
		{
			if (img_row[j] > Ilow)
			{
				float aa = abs(img_row[j] - img_row[j - 1]);
				float bb = abs(img_row[j] - img_row[j + 1]);

				if ((aa < Ihigh) && (bb < Ihigh))
				{
					GrayAdd[i][j] = img_row[j - 1] + img_row[j] + img_row[j + 1];
					Bool[i] = 1;

					if (row_max < GrayAdd[i][j])
					{
						row_max = GrayAdd[i][j];
						idx_left = j;
					}
					if (row_max == GrayAdd[i][j])
					{
						idx_right = j;
					}
				}
			}
		}
		C[i] = idx_left + (idx_right - idx_left) / 2;
	}

	//int thresh_grad = 5;
	//int *C = new int[Height];//����洢ÿ������λ��;
	//for (int i = 0; i < Height; i++)
	//{
	//	uchar* img_row = imagegray.ptr<uchar>(i);
	//	C[i] = 0;
	//	int idx_left = 0;
	//	int idx_right = 0;

	//	for (int j = BandWidth; j < Width - BandWidth; j++)
	//	{
	//		if (img_row[j] > Ilow)
	//		{
	//			float aa = abs(img_row[j] - img_row[j - 1]);
	//			if (aa > thresh_grad)
	//			{
	//				Bool[i] = 1;
	//				idx_left = j;
	//				break;
	//			}
	//		}
	//	}
	//	for (int j = Width - BandWidth; j > BandWidth; j--)
	//	{
	//		if (img_row[j] > Ilow)
	//		{
	//			float aa = abs(img_row[j] - img_row[j - 1]);
	//			if (aa > thresh_grad)
	//			{
	//				idx_right = j;
	//				break;
	//			}
	//		}
	//	}
	//	C[i] = idx_left + (idx_right - idx_left) / 2;	
	//}


	//��������ȣ�ȥ����������
	for (int i = 0; i < Height; i++)
	{
		int center = C[i];
		if (center != 0)
		{
			int center_val = imagegray.at<uchar>(i, center);
			int left_val = imagegray.at<uchar>(i, center - BandWidth);
			int right_val = imagegray.at<uchar>(i, center + BandWidth);
			int aa = abs(2 * center_val - (left_val + right_val));
			if (aa < 10 || (center_val - left_val  < 10) || (center_val - right_val < 10))
			{
				C[i] = 0; //���ȥ��ȥ������
			}
		}
	}

	//�۲����������λ��;
	cv::Mat imageLook = imagegray.clone();
	//cvtColor(imageLook, imageLook, CV_GRAY2BGR);
	for (int i = 0; i < Height; i++)
	{
		if (Bool[i] == 1)
		{
			int m = C[i];
			imageLook.at<uchar>(i, m) = 0;
		}

	}
	//addWeighted(Image, 0.5, imageLook, 0.5, 0, imageLook);
	//imshow("����",imageLook);


	//�ҳ�������򣬶Թ������ͼ����е�ͨ�˲�;
	//cv::imwrite("culue.bmp", imageLook);
	int Nw = BandWidth;
	cv::Mat imageLiner = cv::Mat::zeros(Height, Width, CV_32FC1);

	vector<float> vLaserData; //����������ֵ;
	vector<float> vThresh(Height, 0.0);
	for (int i = 0; i < Height; i++)
	{
		vLaserData.clear();
		int m = C[i];
		if (m && (m - Nw) >= 0 && (m + Nw) < Width)
		{
			for (int j = m - Nw; j <= m + Nw; j++)
			{
				if (j<2 || j>Width - 3)
				{
					continue;
				}

				float fTemp = 0.370286*imagegray.at<uchar>(i, j) + 0.271843*(imagegray.at<uchar>(i, j - 1) + imagegray.at<uchar>(i, j + 1))
					+ 0.095016*(imagegray.at<uchar>(i, j - 2) + imagegray.at<uchar>(i, j + 2));
				imageLiner.at<float>(i, j) = sqrt(sqrt(fTemp));
				vLaserData.push_back(imageLiner.at<float>(i, j));
			}
			float fTh = getThresh(vLaserData);
			vThresh[i] = fTh;
		}
	}
	Mat imageLiner_tmp = imageLiner.clone();
	for (int i = 0; i < Height; i++)
	{
		int m = C[i];
		for (int j = m - Nw; j <= m + Nw; j++)
		{
			if (j<2 || j>Width - 3)
			{
				continue;
			}
			if (imageLiner.at<float>(i, j) < vThresh[i])
			{
				imageLiner_tmp.at<float>(i, j) = 0;
			}
		}
	}
	//��ȡ��ȷ����λ��;
	vector<vector<double> > Gx(Height);
	for (int i = 0; i < Height; ++i)
		Gx[i].resize(Width, 0);

	vector<vector<double> > P(Height);

	for (int i = 0; i < Height; ++i)
		P[i].resize(Width, 0);                    //����ݶ�ֵ��Ӧλ��

	for (int m = 0; m < Height; m++)
	{
		if (vThresh[m] <= 0.0)
		{
			continue;
		}

		int xm = C[m];
		if (!xm || (xm - Nw) < 0 && (xm + Nw) > Width)
		{
			continue;
		}
		for (int n = xm - Nw; n <= xm + Nw; n++)
		{
			if (imageLiner.at<float>(m, n) < vThresh[m] && imageLiner.at<float>(m, n + 1) < vThresh[m])
			{
				Gx[m][n] = 0.0;
			}
			else if ((imageLiner.at<float>(m, n) < vThresh[m] || imageLiner.at<float>(m, n) == vThresh[m]) && imageLiner.at<float>(m, n + 1) > vThresh[m])
			{
				Gx[m][n] = abs(imageLiner.at<float>(m, n + 1) - vThresh[m]);
				P[m][n] = n + 1 - Gx[m][n] / (2 * abs(imageLiner.at<float>(m, n) - imageLiner.at<float>(m, n + 1)));
			}
			else if ((imageLiner.at<float>(m, n + 1) < vThresh[m] || imageLiner.at<float>(m, n + 1) == vThresh[m]) && imageLiner.at<float>(m, n) > vThresh[m])
			{
				Gx[m][n] = abs(imageLiner.at<float>(m, n) - vThresh[m]);
				P[m][n] = n + Gx[m][n] / (2 * abs(imageLiner.at<float>(m, n) - imageLiner.at<float>(m, n + 1)));
			}
			else if (imageLiner.at<float>(m, n) > vThresh[m] && imageLiner.at<float>(m, n + 1) > vThresh[m])
			{
				Gx[m][n] = abs(imageLiner.at<float>(m, n) - imageLiner.at<float>(m, n + 1));
				P[m][n] = n + 0.5;
			}
		}

	}
	cv::Mat img5;
	cvtColor(imageLiner, img5, CV_GRAY2BGR);
	if (Image.channels()==1)
	{
		cvtColor(Image, Image, CV_GRAY2BGR);
	}
	vector<float> Cw(Height);//����洢������λ��;
	for (int i = 0; i < Height; i++)
	{
		double m = C[i];
		double mm = 0;
		float nn = 0;
		if (m && (m - Nw) >= 0 && (m + Nw) < Width)
		{
			for (int j = m - Nw; j < m + Nw; j++)
			{
				mm = Gx[i][j] * P[i][j] + mm;
				nn = Gx[i][j] + nn;
			}
			if (!(mm && nn))
			{
				Cw[i] = 0.0;
				continue;
			}
			Cw[i] = mm / nn;
			int pp = (int)(Cw[i] + 0.5);
			int pp2 = (int)Cw[i];
			if (pp < 0 || pp >= Width)
			{
				continue;
			}
			Image.at<cv::Vec3b>(i, pp) = cv::Vec3b(255, 0, 0);
		}
		else
		{
			Cw[i] = 0.0;
		}

	}

	vSubCenterPoint.clear();
	for (int i = 0; i < Height; i++)
	{
		if (Cw[i] != 0.0)
		{
			vSubCenterPoint.push_back(cv::Point2f(Cw[i], i));
		}
	}


	dst = Image.clone();
	//imshow("w", dst);
	//waitKey(0);

	return true;
}

/**/
int OtsuAlgThreshold(const Mat image)
{
	if (image.channels() != 1)
	{
		cout << "Please input Gray-image!" << endl;
		return 0;
	}
	int T = 0; //Otsu�㷨��ֵ  
	double varValue = 0; //��䷽���м�ֵ����  
	double w0 = 0; //ǰ�����ص�����ռ����  
	double w1 = 0; //�������ص�����ռ����  
	double u0 = 0; //ǰ��ƽ���Ҷ�  
	double u1 = 0; //����ƽ���Ҷ�  
	double Histogram[256] = { 0 }; //�Ҷ�ֱ��ͼ���±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ�����ص�����  
	uchar *data = image.data;
	double totalNum = image.rows*image.cols; //��������  
	//����Ҷ�ֱ��ͼ�ֲ���Histogram�����±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ���ص���  
	for (int i = 0; i<image.rows; i++)   //Ϊ������������û�а�rows��cols���������  
	{
		for (int j = 0; j<image.cols; j++)
		{
			Histogram[data[i*image.step + j]]++;
		}
	}
	for (int i = 0; i<255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������  
		w1 = 0;       u1 = 0;       w0 = 0;       u0 = 0;
		//***********����������ֵ����**************************  
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����  
		{
			w1 += Histogram[j];  //�����������ص�����  
			u1 += j*Histogram[j]; //�������������ܻҶȺ�  
		}
		if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�  
		{
			break;
		}
		u1 = u1 / w1; //��������ƽ���Ҷ�  
		w1 = w1 / totalNum; // �����������ص�����ռ����  
		//***********����������ֵ����**************************  

		//***********ǰ��������ֵ����**************************  
		for (int k = i + 1; k<255; k++)
		{
			w0 += Histogram[k];  //ǰ���������ص�����  
			u0 += k*Histogram[k]; //ǰ�����������ܻҶȺ�  
		}
		if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�  
		{
			break;
		}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�  
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����  
		//***********ǰ��������ֵ����**************************  

		//***********��䷽�����******************************  
		double varValueI = w0*w1*(u1 - u0)*(u1 - u0); //��ǰ��䷽�����  
		if (varValue<varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	return T;
}

bool MeasureDistance::BWdetectCenter(Mat& src, Mat& dst, vector<Point2f>& CtrPoint)
{
	
	Mat gray;
	Mat bw_img;
	dst = src.clone();
	if (src.channels()==3)
	{
		cvtColor(src, gray, CV_BGR2GRAY);
	}
	else
	{
		gray = src.clone();
		cvtColor(dst, dst, CV_GRAY2BGR);
	}
	int bw_threshold = OtsuAlgThreshold(gray);
	cv::threshold(gray, bw_img, bw_threshold, 255, CV_THRESH_BINARY);

	for (int i = 0; i < bw_img.rows; i++)
	{
		int start_idx = 0, end_idx = 0;
		bool flag = false;
		for (int j = 1; j < bw_img.cols - 1; j++)
		{
			if (bw_img.at<uchar>(i, j - 1) == 0 && bw_img.at<uchar>(i, j) == 255)
			{
				start_idx = j;
				flag = true;
			}
			if (bw_img.at<uchar>(i, j) == 255 && bw_img.at<uchar>(i, j + 1) == 0)
			{
				end_idx = j;
				continue;
			}
		}

		if (flag)
		{
			int x = start_idx + (end_idx - start_idx) / 2;
			int y = i;
			CtrPoint.push_back(Point2f(x, y));
			dst.at<Vec3b>(i, x) = Vec3b(0, 255, 255);
		}

	}

	return true;
}


bool MeasureDistance::match(Mat& leftImg, Mat& rightImg, Mat& F, vector<Point2f>& lefts, vector<Point2f>& rights, vector<Match>& matches, Mat& matchMat, double threshold)
{
	//double threshold = 3.0; //������������ֵ
	if (lefts.empty() || rights.empty())
	{
		return false;
	}
	vector<Vec3f> line;

	//�㵽��ֱ�ߵľ���;
	computeCorrespondEpilines(lefts, 1, F, line);
	for (int i = 0; i != line.size(); i++)
	{
		Point p_left = lefts[i];
		Point p_right;
		double min_d = INFINITY;
		int idx;
		for (int j = 0; j != rights.size(); j++)
		{
			p_right = rights[j];
			double d = abs(line[i][0] * p_right.x + line[i][1] * p_right.y + line[i][2])
				/ (sqrt(line[i][0] * line[i][0] + line[i][1] * line[i][1]));

			if (min_d > d)
			{
				idx = j;
				min_d = d;
			}
		}

		//����������
		if (min_d < threshold)
		{
			matches.push_back(Match(p_left, rights[idx], min_d));
		}
	}
	cout << "��ֵ������ size:" << matches.size() << endl;
	//Mat_<double> F_ = F;
	////���ݼ���Լ��ƥ��
	//for (int i = 0; i != lefts.size(); i++)
	//{
	//	Point p_left = lefts[i];
	//	Point p_right;
	//	Mat pl(Matx31d(p_left.x, p_left.y, 1.0));
	//	Mat_<double> Lpr = F_*pl; //��ǰ��ͼ���Ӧ��ͼ�еļ���
	//	double min_d = INFINITY;
	//	int idx;
	//	for (int j = 0; j != rights.size(); j++)
	//	{
	//		p_right = rights[j];
	//		double d = abs(Lpr(0)*p_right.x + Lpr(1)*p_right.y + Lpr(2))
	//			/ (sqrt(Lpr(0)*Lpr(0) + Lpr(1)*Lpr(1)));
	//		if (min_d > d)
	//		{
	//			idx = j;
	//			min_d = d;
	//		}
	//	}
	//	
	//	//����������
	//	if (min_d < threshold) 
	//	{
	//		matches.push_back(Match(p_left, rights[idx], min_d));
	//	}	
	//}

	//����,ȥ��һ�Զ�ƥ��
	sort(matches.begin(), matches.end(),
		[](Match a, Match b){
		if (a.right.x == b.right.x && a.right.y == b.right.y)
		{
			return a.distance < b.distance;
		}
		else
		{
			if (a.right.y == b.right.y)
			{
				return a.right.x < b.right.x;
			}
			else return a.right.y < b.right.y;
		}
	});

	int idx = 0;
	for (int i = 1; i != matches.size(); i++)
	{
		if ((matches[idx].right.x != matches[i].right.x) || (matches[idx].right.y != matches[i].right.y))
		{
			matches[idx + 1] = matches[i];
		}
		else
			continue;
		idx++;
	}

	matches.erase(matches.begin() + idx, matches.end());

	//show point match 
	Size si = leftImg.size();
	Mat matchImg(leftImg.rows, leftImg.cols * 2, CV_8UC3, Scalar(0, 0, 0));
	leftImg.copyTo(matchImg(Rect(0, 0, si.width, si.height)));
	rightImg.copyTo(matchImg(Rect(si.width, 0, si.width, si.height)));
	for (int i = 0; i < matches.size(); i+=5)
	{
		Point start = matches[i].left;
		Point end(matches[i].right.x + si.width, matches[i].right.y);

		//cv::circle(matchImg, start, 2, Scalar(0, 0, 255));
		//cv::circle(matchImg, end, 2, Scalar(0, 0, 255));
		cv::line(matchImg, start, end, Scalar(0, 255, 255));

	}

	matchMat = matchImg.clone();
	//imshow("match.", matchImg);
	//waitKey();

	return true;
}

bool MeasureDistance::reprojectTo3D(Mat& M1, Mat& M2, Mat& R, Mat& t, vector<Match> matches, vector<Point3d>& real_points)
{
	Mat_<double> M1_ = M1;
	Mat_<double> M2_ = M2;
	Mat_<double> R_ = R;
	Mat_<double> t_ = t;

	double fl = (M1_(0, 0) + M1_(1, 1)) / 2;
	double fr = (M2_(0, 0) + M2_(1, 1)) / 2;

	for (int i = 0; i != matches.size(); i++)
	{
		Point left = matches[i].left;
		Point right = matches[i].right;
		double Xl = left.x - M1_(0, 2);
		double Xr = right.x - M2_(0, 2);
		double Yl = left.y - M1_(1, 2);
		double Yr = right.y - M2_(1, 2);

		Point3d p;

		p.z = fl*(fr*t_(0) - Xr*t_(2))
			/ ((Xr*(Xl*R_(2, 0) + Yl*R_(2, 1) + fl*R_(2, 2)) - fr*(Xl*R_(0, 0) + Yl*R_(0, 1) + fl*R_(0, 2))));
		p.x = p.z*Xl / fl;
		p.y = p.z*Yl / fl;

		real_points.push_back(p);
	}
	
	/*ofstream fout("real_points.txt");
	for (int i = 0; i != real_points.size(); i++)
	{
		Point3d p = real_points[i];
		Match m = matches[i];
		fout << p.x << "," << p.y << "," << p.z << "  ,       [===]     ";
		fout << "(" << m.left.x << "," << m.left.y << ")" << ", <-->";
		fout << "(" << m.right.x << "," << m.right.y << "),  ";
		fout << m.distance << endl;

	}*/
	return true;
}

bool MeasureDistance::caculateDistance(Mat& left_img, Mat& right_img, CameraCalib::CalibrationParames& calibResult, vector<Point3d>& real_points, Mat& outLeftCenterMat, Mat& outRightCenterMat, Mat& matchCenterMat)
{
	Mat M1 = calibResult.mLeftCameraInParas;
	Mat M2 = calibResult.mRightCameraInParas;
	Mat D1 = calibResult.mLeftCameraDistorParas;
	Mat D2 = calibResult.mRightCameraDistorParas;
	Mat F = calibResult.mFoundational;
	Mat R = calibResult.mL2RRotation33;
	Mat t = calibResult.mL2RTranslation;

	vector<Match> matches;

	Mat undist_left, undist_right;
	undistort(left_img, undist_left, M1, D1);
	undistort(right_img, undist_right, M2, D2);

	Mat left_out, right_out;
	vector<Point2f> left_reds;
	vector<Point2f> right_reds;
// 	color_filter(undist_left, left_out, left_reds);
// 	color_filter(undist_right, right_out, right_reds);

	vector<Point2f> leftCtrPoint;
	vector<Point2f> rightCtrPoint;

	Mat leftDst, rightDst;
	DetectLinerCenterHor(undist_left, outLeftCenterMat, leftCtrPoint);
	DetectLinerCenterHor(undist_right, outRightCenterMat, rightCtrPoint);

	match(undist_left, undist_right, F, leftCtrPoint, rightCtrPoint, matches, matchCenterMat, 1);
	
	reprojectTo3D(M1, M2, R, t, matches, real_points);

	return true;
}

bool MeasureDistance::BWcaculateDistance(const Mat& Mode_left, const Mat& Mode_right, Mat& left_img, Mat& right_img, CameraCalib::CalibrationParames& calibResult, vector<Point3d>& real_points, Mat& matchCenterMat)
{
	Mat M1 = calibResult.mLeftCameraInParas;
	Mat M2 = calibResult.mRightCameraInParas;
	Mat D1 = calibResult.mLeftCameraDistorParas;
	Mat D2 = calibResult.mRightCameraDistorParas;
	Mat F = calibResult.mFoundational;
	Mat R = calibResult.mL2RRotation33;
	Mat t = calibResult.mL2RTranslation;

	vector<Match> matches;

	//Mat undist_left, undist_right;
	//undistort(left_img, undist_left, M1, D1);
	//undistort(right_img, undist_right, M2, D2);

	Mat leftDst, rightDst;
	vector<Point2f> leftCtrPoint;
	vector<Point2f> rightCtrPoint;

	Mat left_gray, right_gray, mdleft_gray, mdright_gray;
	cvtColor(left_img, left_gray, CV_BGR2GRAY);
	cvtColor(right_img, right_gray, CV_BGR2GRAY);
	cvtColor(Mode_left, mdleft_gray, CV_BGR2GRAY);
	cvtColor(Mode_right, mdright_gray, CV_BGR2GRAY);

	int width = left_img.cols;
	int height = left_img.rows;
	for (int i = 0; i < height; i ++)
	{
		uchar* left_ptr = left_gray.ptr<uchar>(i);
		uchar* right_ptr = right_gray.ptr<uchar>(i);
		uchar* mdleft_ptr = mdleft_gray.ptr<uchar>(i);
		uchar* mdright_ptr = mdright_gray.ptr<uchar>(i);

		for (int j = 0; j < width; j++)
		{
			left_ptr[j] = abs(mdleft_ptr[j] - left_ptr[j]);
			right_ptr[j] = abs(mdright_ptr[j] - right_ptr[j]);
		}
	}

	//addWeighted(Mode_left,)

	//BWdetectCenter(left_gray, leftDst, leftCtrPoint);
	//BWdetectCenter(right_gray, rightDst, rightCtrPoint);
	DetectLinerCenterHor(left_gray, leftDst, leftCtrPoint);
	DetectLinerCenterHor(right_gray, rightDst, rightCtrPoint);

	match(left_img, right_img, F, leftCtrPoint, rightCtrPoint, matches, matchCenterMat, 3);

	reprojectTo3D(M1, M2, R, t, matches, real_points);

	return true;
}
